
# Predictive Analytics Using Historical Data

## Project Objective
This project builds a professional predictive analytics system capable of forecasting future trends using historical business data.

The project includes:
- Synthetic dataset generation
- CSV dataset support
- Data cleaning & preprocessing
- Exploratory Data Analysis (EDA)
- Machine Learning models
- Time Series forecasting
- Hyperparameter tuning
- Model evaluation
- Visualization & reporting

---

## Project Structure

Predictive_Analytics_Project/

├── data/

├── notebooks/

├── src/

├── outputs/

├── main.py

├── requirements.txt

└── README.md

---

## Features

### Dataset Handling
- Synthetic dataset generation (1000+ records)
- CSV loading support
- Missing values simulation
- Outlier simulation
- Noise injection

### Preprocessing
- Missing value handling
- Duplicate removal
- Outlier detection
- Feature engineering
- Scaling
- Encoding

### Models
Regression Models:
- Linear Regression
- Decision Tree Regressor
- Random Forest Regressor
- XGBoost Regressor

Time Series Models:
- ARIMA
- Exponential Smoothing

### Evaluation Metrics
- MAE
- MSE
- RMSE
- R² Score
- MAPE

### Forecasting
- Next 7 Days
- Next 30 Days
- Next 6 Months

---

## Installation

```bash
pip install -r requirements.txt
```

---

## Run Project

```bash
python main.py
```

---

## Outputs
Generated outputs include:
- Cleaned datasets
- Forecast CSVs
- Model evaluation reports
- Charts
- Trend visualizations

---

## Internship Project Highlights
This project is designed as a professional internship-level data science project with modular architecture, detailed documentation, reusable pipelines, and production-style implementation.
