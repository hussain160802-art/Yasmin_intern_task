
import pandas as pd
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)
import numpy as np

def mean_absolute_percentage_error(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

def evaluate_models(y_test, predictions):

    results = []

    for model_name, preds in predictions.items():

        mae = mean_absolute_error(y_test, preds)
        mse = mean_squared_error(y_test, preds)
        rmse = np.sqrt(mse)
        r2 = r2_score(y_test, preds)
        mape = mean_absolute_percentage_error(y_test, preds)

        results.append({
            'Model': model_name,
            'MAE': mae,
            'MSE': mse,
            'RMSE': rmse,
            'R2 Score': r2,
            'MAPE': mape
        })

    evaluation_df = pd.DataFrame(results)

    print("\nModel Evaluation Results")
    print(evaluation_df)

    evaluation_df.to_csv("outputs/predictions/model_evaluation.csv", index=False)

    return evaluation_df
