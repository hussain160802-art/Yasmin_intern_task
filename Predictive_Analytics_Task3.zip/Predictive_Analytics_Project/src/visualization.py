
import matplotlib.pyplot as plt
import seaborn as sns

def dataset_overview(df):

    print("\nDataset Shape:", df.shape)
    print(df.describe())
    print(df.info())

def null_analysis(df):

    print("\nNull Value Analysis")
    print(df.isnull().sum())

def distribution_plots(df):

    numerical_cols = [
        'Sales',
        'Revenue',
        'Marketing_Spend'
    ]

    for col in numerical_cols:

        plt.figure(figsize=(8,5))

        sns.histplot(df[col], kde=True)

        plt.title(f"{col} Distribution")

        plt.savefig(f"outputs/charts/{col}_distribution.png")

def box_plots(df):

    numerical_cols = [
        'Sales',
        'Revenue',
        'Website_Traffic'
    ]

    for col in numerical_cols:

        plt.figure(figsize=(8,5))

        sns.boxplot(x=df[col])

        plt.title(f"{col} Box Plot")

        plt.savefig(f"outputs/charts/{col}_boxplot.png")

def correlation_heatmap(df):

    plt.figure(figsize=(12,8))

    sns.heatmap(df.corr(numeric_only=True), annot=True, cmap='coolwarm')

    plt.title("Correlation Heatmap")

    plt.savefig("outputs/charts/correlation_heatmap.png")

def monthly_trend(df):

    monthly = df.groupby('Month')['Revenue'].mean()

    plt.figure(figsize=(10,6))

    monthly.plot()

    plt.title("Monthly Revenue Trend")

    plt.savefig("outputs/charts/monthly_revenue_trend.png")

def region_analysis(df):

    plt.figure(figsize=(10,6))

    sns.barplot(x='Region', y='Revenue', data=df)

    plt.title("Region Wise Revenue")

    plt.savefig("outputs/charts/region_wise_revenue.png")

def actual_vs_predicted(y_test, predictions):

    for model_name, preds in predictions.items():

        plt.figure(figsize=(10,6))

        plt.plot(y_test.values[:100], label='Actual')
        plt.plot(preds[:100], label='Predicted')

        plt.legend()

        plt.title(f"Actual vs Predicted - {model_name}")

        plt.savefig(f"outputs/charts/{model_name}_actual_vs_predicted.png")

def feature_importance(models):

    for name, model in models.items():

        if hasattr(model, 'feature_importances_'):

            plt.figure(figsize=(10,6))

            sns.barplot(
                x=model.feature_importances_,
                y=[f'Feature_{i}' for i in range(len(model.feature_importances_))]
            )

            plt.title(f"Feature Importance - {name}")

            plt.savefig(f"outputs/charts/{name}_feature_importance.png")

def run_all_visualizations(df, y_test, predictions, models):

    dataset_overview(df)

    null_analysis(df)

    distribution_plots(df)

    box_plots(df)

    correlation_heatmap(df)

    monthly_trend(df)

    region_analysis(df)

    actual_vs_predicted(y_test, predictions)

    feature_importance(models)
