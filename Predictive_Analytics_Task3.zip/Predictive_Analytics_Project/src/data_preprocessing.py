
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler

def generate_synthetic_dataset(num_records=1500):
    np.random.seed(42)

    dates = pd.date_range(start='2021-01-01', periods=num_records, freq='D')

    regions = ['North', 'South', 'East', 'West']

    data = {
        'Date': dates,
        'Sales': np.random.normal(5000, 1200, num_records),
        'Revenue': np.random.normal(20000, 5000, num_records),
        'Marketing_Spend': np.random.normal(3000, 700, num_records),
        'Website_Traffic': np.random.normal(15000, 4000, num_records),
        'Customer_Count': np.random.normal(800, 150, num_records),
        'Product_Demand': np.random.normal(400, 90, num_records),
        'Region': np.random.choice(regions, num_records)
    }

    df = pd.DataFrame(data)

    # Inject missing values
    for col in ['Sales', 'Revenue', 'Website_Traffic']:
        missing_indices = np.random.choice(df.index, size=30, replace=False)
        df.loc[missing_indices, col] = np.nan

    # Inject outliers
    outlier_indices = np.random.choice(df.index, size=20, replace=False)
    df.loc[outlier_indices, 'Sales'] *= 4

    # Add duplicates
    df = pd.concat([df, df.iloc[:10]], ignore_index=True)

    return df

def load_or_generate_dataset(csv_path=None):
    if csv_path:
        df = pd.read_csv(csv_path)
    else:
        df = generate_synthetic_dataset()

    df.to_csv("data/historical_data.csv", index=False)

    return df

def handle_missing_values(df):
    numerical_cols = df.select_dtypes(include=np.number).columns

    for col in numerical_cols:
        df[col] = df[col].fillna(df[col].median())

    return df

def remove_duplicates(df):
    return df.drop_duplicates()

def detect_and_remove_outliers(df):
    numerical_cols = df.select_dtypes(include=np.number).columns

    for col in numerical_cols:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1

        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR

        df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]

    return df

def preprocess_data(df):

    print("\nHandling Missing Values...")
    df = handle_missing_values(df)

    print("Removing Duplicates...")
    df = remove_duplicates(df)

    print("Removing Outliers...")
    df = detect_and_remove_outliers(df)

    df['Date'] = pd.to_datetime(df['Date'])

    df['Year'] = df['Date'].dt.year
    df['Month'] = df['Date'].dt.month
    df['Day'] = df['Date'].dt.day
    df['Weekday'] = df['Date'].dt.weekday

    encoder = LabelEncoder()
    df['Region_Encoded'] = encoder.fit_transform(df['Region'])

    scaler = StandardScaler()

    numeric_cols = [
        'Sales',
        'Revenue',
        'Marketing_Spend',
        'Website_Traffic',
        'Customer_Count',
        'Product_Demand'
    ]

    df[numeric_cols] = scaler.fit_transform(df[numeric_cols])

    return df
