
import pandas as pd
import matplotlib.pyplot as plt
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.holtwinters import ExponentialSmoothing

def forecast_future(df):

    ts = df.sort_values('Date')

    ts = ts.set_index('Date')

    revenue_series = ts['Revenue']

    arima_model = ARIMA(revenue_series, order=(5,1,0))
    arima_fit = arima_model.fit()

    forecast_7 = arima_fit.forecast(steps=7)
    forecast_30 = arima_fit.forecast(steps=30)

    exp_model = ExponentialSmoothing(
        revenue_series,
        trend='add',
        seasonal=None
    )

    exp_fit = exp_model.fit()

    forecast_6m = exp_fit.forecast(steps=180)

    forecast_7.to_csv("outputs/predictions/forecast_7_days.csv")
    forecast_30.to_csv("outputs/predictions/forecast_30_days.csv")
    forecast_6m.to_csv("outputs/predictions/forecast_6_months.csv")

    plt.figure(figsize=(12,6))

    revenue_series.plot(label='Historical Revenue')

    forecast_30.plot(label='30 Day Forecast')

    plt.legend()

    plt.title("Revenue Forecast")

    plt.savefig("outputs/charts/revenue_forecast.png")

    print("\nForecasts generated successfully.")
