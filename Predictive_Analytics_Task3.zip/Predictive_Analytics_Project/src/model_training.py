
import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error
from sklearn.feature_selection import SelectKBest, f_regression

try:
    from xgboost import XGBRegressor
    xgb_available = True
except:
    xgb_available = False

def train_models(df):

    target = 'Revenue'

    features = [
        'Sales',
        'Marketing_Spend',
        'Website_Traffic',
        'Customer_Count',
        'Product_Demand',
        'Month',
        'Weekday',
        'Region_Encoded',
        'Rolling_Sales_Mean_7'
    ]

    X = df[features]
    y = df[target]

    selector = SelectKBest(score_func=f_regression, k=7)
    X_selected = selector.fit_transform(X, y)

    X_train, X_test, y_train, y_test = train_test_split(
        X_selected,
        y,
        test_size=0.2,
        random_state=42
    )

    models = {
        'Linear Regression': LinearRegression(),
        'Decision Tree': DecisionTreeRegressor(random_state=42),
        'Random Forest': RandomForestRegressor(random_state=42)
    }

    if xgb_available:
        models['XGBoost'] = XGBRegressor()

    trained_models = {}
    predictions = {}
    results = {}

    for name, model in models.items():

        print(f"\nTraining {name}...")

        if name == 'Random Forest':

            params = {
                'n_estimators': [50, 100],
                'max_depth': [5, 10]
            }

            grid = GridSearchCV(
                model,
                params,
                cv=3,
                scoring='neg_mean_absolute_error'
            )

            grid.fit(X_train, y_train)

            best_model = grid.best_estimator_

        else:
            best_model = model.fit(X_train, y_train)

        trained_models[name] = best_model

        preds = best_model.predict(X_test)

        predictions[name] = preds

        cv_score = cross_val_score(
            best_model,
            X_selected,
            y,
            cv=5,
            scoring='r2'
        ).mean()

        results[name] = {
            'Cross_Validation_R2': cv_score
        }

    return results, trained_models, X_test, y_test, predictions
