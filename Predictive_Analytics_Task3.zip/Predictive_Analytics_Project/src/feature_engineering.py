
import pandas as pd

def create_rolling_features(df):

    df = df.sort_values('Date')

    df['Rolling_Sales_Mean_7'] = df['Sales'].rolling(window=7).mean()
    df['Rolling_Revenue_Mean_7'] = df['Revenue'].rolling(window=7).mean()

    df['Lag_Sales_1'] = df['Sales'].shift(1)
    df['Lag_Sales_7'] = df['Sales'].shift(7)

    df.fillna(method='bfill', inplace=True)

    return df

def create_growth_metrics(df):

    df['Sales_Growth'] = df['Sales'].pct_change().fillna(0)
    df['Revenue_Growth'] = df['Revenue'].pct_change().fillna(0)

    return df

def feature_engineering_pipeline(df):

    df = create_rolling_features(df)

    df = create_growth_metrics(df)

    return df
