
from src.data_preprocessing import load_or_generate_dataset, preprocess_data
from src.feature_engineering import feature_engineering_pipeline
from src.model_training import train_models
from src.evaluation import evaluate_models
from src.forecasting import forecast_future
from src.visualization import run_all_visualizations

def main():
    print("=" * 60)
    print("PREDICTIVE ANALYTICS PROJECT")
    print("=" * 60)

    df = load_or_generate_dataset()
    cleaned_df = preprocess_data(df)

    engineered_df = feature_engineering_pipeline(cleaned_df)

    model_results, trained_models, X_test, y_test, predictions = train_models(engineered_df)

    evaluation_df = evaluate_models(y_test, predictions)

    run_all_visualizations(engineered_df, y_test, predictions, trained_models)

    forecast_future(engineered_df)

    print("\nProject Execution Completed Successfully!")

if __name__ == "__main__":
    main()
