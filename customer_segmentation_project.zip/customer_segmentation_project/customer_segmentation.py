
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# Load data
df = pd.read_csv("customers.csv")

# Select features
features = ["Age","AnnualIncome","PurchaseFrequency","SpendingScore"]
X = df[features]

# Scale data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# KMeans clustering
kmeans = KMeans(n_clusters=4, random_state=42, n_init=10)
df["Cluster"] = kmeans.fit_predict(X_scaled)

# Summary
print("\nCustomer Segment Summary:\n")
print(df.groupby("Cluster")[features].mean())

# Visualization
plt.figure(figsize=(8,5))
plt.scatter(df["AnnualIncome"], df["SpendingScore"], c=df["Cluster"])
plt.xlabel("Annual Income")
plt.ylabel("Spending Score")
plt.title("Customer Segmentation")
plt.savefig("customer_segments.png")
print("\nVisualization saved as customer_segments.png")
