# Customer Segmentation Project

## Objective
Segment customers based on behavior and demographics using Machine Learning.

## Features
- Customer clustering using Python + scikit-learn
- Purchase pattern analysis
- Segment visualization
- Targeted customer insights

## Files
- customer_segmentation.py → Main clustering code
- customers.csv → Sample dataset
- requirements.txt → Required libraries

## Run
pip install -r requirements.txt
python customer_segmentation.py
