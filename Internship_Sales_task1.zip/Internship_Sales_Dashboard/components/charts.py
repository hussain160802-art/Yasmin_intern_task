
import plotly.express as px
def revenue_trend(df):
    return px.line(df,x='Date',y='Revenue',color='Region',title='Revenue Trend')

def top_products(df):
    gp=df.groupby('Product')['Revenue'].sum().reset_index()
    return px.bar(gp,x='Product',y='Revenue',color='Product',title='Top Products')
