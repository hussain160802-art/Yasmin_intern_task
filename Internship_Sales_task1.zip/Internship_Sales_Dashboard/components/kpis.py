
def metrics(df):
    return {
        'Total Revenue': int(df['Revenue'].sum()),
        'Total Units': int(df['Units_Sold'].sum()),
        'Avg Revenue': round(df['Revenue'].mean(),2)
    }
