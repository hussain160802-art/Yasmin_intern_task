
# Internship Level Sales & Revenue Analysis Dashboard

Detailed Project Features:
- Import from CSV / Excel / Database
- KPI Cards
- Revenue Trends
- Top Product Analysis
- Interactive Filters & Slicers
- Modular Code Structure
- Business Insight Section
- Sample Dataset Included

Run:

pip install -r requirements.txt
streamlit run app.py
