
import streamlit as st
import pandas as pd
from sqlalchemy import create_engine
from components.charts import revenue_trend, top_products
from components.kpis import metrics

st.set_page_config(page_title="Sales & Revenue Dashboard", layout="wide")
st.title("📊 Sales & Revenue Analysis Dashboard")

st.sidebar.header("Data Import")

source = st.sidebar.radio("Select Source",["CSV","Excel","Database","Sample Data"])

if source=="CSV":
    file = st.sidebar.file_uploader("Upload CSV", type=["csv"])
    df = pd.read_csv(file) if file else pd.read_csv("sales_data.csv")
elif source=="Excel":
    file = st.sidebar.file_uploader("Upload Excel", type=["xlsx"])
    df = pd.read_excel(file) if file else pd.read_csv("sales_data.csv")
elif source=="Database":
    st.sidebar.info("SQLite demo connection")
    eng = create_engine("sqlite:///sales.db")
    try:
        df = pd.read_sql("SELECT * FROM sales", eng)
    except:
        df = pd.read_csv("sales_data.csv")
else:
    df = pd.read_csv("sales_data.csv")

df['Date']=pd.to_datetime(df['Date'])

st.sidebar.header("Interactive Filters")
region = st.sidebar.multiselect("Region", df['Region'].unique(), default=df['Region'].unique())
product = st.sidebar.multiselect("Product", df['Product'].unique(), default=df['Product'].unique())

fdf = df[(df['Region'].isin(region)) & (df['Product'].isin(product))]

m = metrics(fdf)
c1,c2,c3 = st.columns(3)
c1.metric("Total Revenue", f"${m['Total Revenue']:,}")
c2.metric("Units Sold", m['Total Units'])
c3.metric("Average Revenue", f"${m['Avg Revenue']:,}")

col1,col2 = st.columns(2)
with col1:
    st.plotly_chart(revenue_trend(fdf), use_container_width=True)
with col2:
    st.plotly_chart(top_products(fdf), use_container_width=True)

st.subheader("Detailed Data Table")
st.dataframe(fdf, use_container_width=True)

st.subheader("Business Insights")
top = fdf.groupby('Product')['Revenue'].sum().idxmax()
st.success(f"Top Performing Product: {top}")
