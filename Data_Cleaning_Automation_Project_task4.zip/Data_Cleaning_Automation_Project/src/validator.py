
import pandas as pd


class DataValidator:

    REQUIRED_COLUMNS = [
        "customer_id",
        "name",
        "email",
        "department",
        "sales",
        "revenue",
        "date",
        "region",
        "product_category",
        "status"
    ]

    def __init__(self, dataframe):
        self.df = dataframe
        self.validation_logs = []

    def validate_schema(self):
        """
        Validate dataset schema.
        """

        missing_columns = [
            col for col in self.REQUIRED_COLUMNS
            if col not in self.df.columns
        ]

        if missing_columns:
            self.validation_logs.append(
                f"Missing columns: {missing_columns}"
            )

    def validate_nulls(self):
        """
        Check null values.
        """

        nulls = self.df.isnull().sum()

        self.validation_logs.append(
            f"Null summary:\n{nulls}"
        )

    def validate_duplicates(self):
        """
        Check duplicate rows.
        """

        duplicates = self.df.duplicated().sum()

        self.validation_logs.append(
            f"Duplicate rows found: {duplicates}"
        )

    def validate_ranges(self):
        """
        Validate sales and revenue ranges.
        """

        invalid_sales = self.df[self.df["sales"] < 0]

        self.validation_logs.append(
            f"Negative sales records: {len(invalid_sales)}"
        )

    def validate_completeness(self):
        """
        Check completeness percentage.
        """

        completeness = (
            1 - self.df.isnull().mean()
        ) * 100

        self.validation_logs.append(
            f"Completeness:\n{completeness}"
        )

    def run_all_validations(self):

        self.validate_schema()
        self.validate_nulls()
        self.validate_duplicates()
        self.validate_ranges()
        self.validate_completeness()

        return self.validation_logs
