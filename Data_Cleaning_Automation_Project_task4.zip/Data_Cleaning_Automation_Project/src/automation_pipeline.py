
from pathlib import Path
from src.data_loader import generate_dataset, load_dataset
from src.cleaner import DataCleaner
from src.validator import DataValidator
from src.visualization import Visualizer
from src.report_generator import ReportGenerator

LOG_PATH = Path("reports/automation_log.txt")


def log_message(message):

    LOG_PATH.parent.mkdir(exist_ok=True)

    with open(LOG_PATH, "a") as file:
        file.write(message + "\n")


def run_pipeline():

    print("=" * 50)
    print("DATA CLEANING AUTOMATION PIPELINE")
    print("=" * 50)

    log_message("Pipeline started")

    # Step 1: Generate Dataset
    generate_dataset(records=1500)

    log_message("Raw dataset generated")

    # Step 2: Load Dataset
    raw_df = load_dataset()

    log_message("Raw dataset loaded")

    # Step 3: Clean Dataset
    cleaner = DataCleaner(raw_df)

    clean_df = cleaner.execute_cleaning_pipeline()

    clean_df.to_csv(
        "data/cleaned_dataset.csv",
        index=False
    )

    log_message("Dataset cleaned")

    # Step 4: Validate Dataset
    validator = DataValidator(clean_df)

    validation_logs = validator.run_all_validations()

    log_message("Validation completed")

    # Step 5: Generate Visualizations
    visualizer = Visualizer(clean_df)

    visualizer.generate_all_visualizations()

    log_message("Visualizations generated")

    # Step 6: Generate Reports
    report_generator = ReportGenerator(
        raw_df,
        clean_df,
        validation_logs
    )

    report_generator.export_excel_report()

    log_message("Excel reports generated")

    print("=" * 50)
    print("PIPELINE COMPLETED SUCCESSFULLY")
    print("=" * 50)
