
import pandas as pd
from pathlib import Path

REPORT_PATH = Path("reports/summary_report.xlsx")


class ReportGenerator:

    def __init__(self, raw_df, clean_df, logs):

        self.raw_df = raw_df
        self.clean_df = clean_df
        self.logs = logs

    def generate_summary_statistics(self):

        summary = {
            "Raw Rows": len(self.raw_df),
            "Cleaned Rows": len(self.clean_df),
            "Columns": len(self.clean_df.columns),
            "Missing Values": self.clean_df.isnull().sum().sum(),
            "Duplicate Rows": self.clean_df.duplicated().sum(),
            "Total Revenue": self.clean_df["revenue"].sum(),
            "Average Revenue": self.clean_df["revenue"].mean()
        }

        return pd.DataFrame(summary.items(), columns=["Metric", "Value"])

    def revenue_analysis(self):

        return (
            self.clean_df.groupby("region")["revenue"]
            .sum()
            .reset_index()
        )

    def department_analysis(self):

        return (
            self.clean_df.groupby("department")["sales"]
            .sum()
            .reset_index()
        )

    def category_analysis(self):

        return (
            self.clean_df.groupby("product_category")["revenue"]
            .sum()
            .reset_index()
        )

    def export_excel_report(self):

        REPORT_PATH.parent.mkdir(exist_ok=True)

        with pd.ExcelWriter(
            REPORT_PATH,
            engine="xlsxwriter"
        ) as writer:

            self.generate_summary_statistics().to_excel(
                writer,
                sheet_name="Summary",
                index=False
            )

            self.revenue_analysis().to_excel(
                writer,
                sheet_name="Revenue Analysis",
                index=False
            )

            self.department_analysis().to_excel(
                writer,
                sheet_name="Department Analysis",
                index=False
            )

            self.category_analysis().to_excel(
                writer,
                sheet_name="Category Analysis",
                index=False
            )

            pd.DataFrame({
                "Validation Logs": self.logs
            }).to_excel(
                writer,
                sheet_name="Validation Logs",
                index=False
            )

        print(f"Report exported to: {REPORT_PATH}")
