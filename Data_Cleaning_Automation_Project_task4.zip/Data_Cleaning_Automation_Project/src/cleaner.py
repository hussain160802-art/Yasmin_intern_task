
import pandas as pd
import numpy as np
import re


class DataCleaner:

    def __init__(self, dataframe):
        self.df = dataframe.copy()

    def rename_columns(self):
        """
        Standardize column naming.
        """
        self.df.columns = [
            col.strip().lower().replace(" ", "_")
            for col in self.df.columns
        ]

    def remove_duplicates(self):
        """
        Remove duplicate records.
        """
        before = len(self.df)

        self.df.drop_duplicates(inplace=True)

        after = len(self.df)

        print(f"Removed {before - after} duplicate rows")

    def clean_strings(self):
        """
        Remove extra spaces and normalize text.
        """
        string_columns = self.df.select_dtypes(include="object").columns

        for col in string_columns:
            self.df[col] = self.df[col].astype(str).str.strip()

    def normalize_case(self):
        """
        Normalize capitalization.
        """
        cols = ["department", "region", "product_category", "status"]

        for col in cols:
            self.df[col] = self.df[col].str.title()

    def fix_dates(self):
        """
        Convert mixed date formats into
        standardized datetime objects.
        """
        self.df["date"] = pd.to_datetime(
            self.df["date"],
            errors="coerce"
        )

    def handle_missing_values(self):
        """
        Fill or remove missing values.
        """
        self.df["name"] = self.df["name"].fillna("Unknown")

        self.df["email"] = self.df["email"].fillna("missing@email.com")

        self.df["department"] = self.df["department"].fillna("Unknown")

        self.df.dropna(subset=["date"], inplace=True)

    def validate_emails(self):
        """
        Remove invalid emails using regex validation.
        """

        email_pattern = r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'

        self.df = self.df[
            self.df["email"].str.match(email_pattern, na=False)
        ]

    def remove_negative_sales(self):
        """
        Remove rows with negative sales values.
        """
        self.df = self.df[self.df["sales"] >= 0]

    def detect_outliers(self):
        """
        Remove revenue outliers using IQR method.
        """

        Q1 = self.df["revenue"].quantile(0.25)
        Q3 = self.df["revenue"].quantile(0.75)

        IQR = Q3 - Q1

        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR

        self.df = self.df[
            (self.df["revenue"] >= lower_bound) &
            (self.df["revenue"] <= upper_bound)
        ]

    def enforce_data_types(self):
        """
        Ensure columns have correct types.
        """

        self.df["sales"] = pd.to_numeric(
            self.df["sales"],
            errors="coerce"
        )

        self.df["revenue"] = pd.to_numeric(
            self.df["revenue"],
            errors="coerce"
        )

    def standardize_categories(self):
        """
        Standardize category labels.
        """
        replacements = {
            "electronics": "Electronics",
            "furniture": "Furniture",
            "food": "Food"
        }

        self.df["product_category"] = (
            self.df["product_category"]
            .replace(replacements)
        )

    def execute_cleaning_pipeline(self):

        print("Starting cleaning pipeline...")

        self.rename_columns()
        self.clean_strings()
        self.normalize_case()
        self.fix_dates()
        self.handle_missing_values()
        self.enforce_data_types()
        self.remove_duplicates()
        self.validate_emails()
        self.remove_negative_sales()
        self.standardize_categories()
        self.detect_outliers()

        print("Cleaning pipeline completed")

        return self.df
