
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

CHART_PATH = Path("visuals/charts")

CHART_PATH.mkdir(parents=True, exist_ok=True)


class Visualizer:

    def __init__(self, dataframe):
        self.df = dataframe

    def revenue_by_region(self):

        plt.figure(figsize=(10, 6))

        self.df.groupby("region")["revenue"].sum().plot(kind="bar")

        plt.title("Revenue by Region")

        plt.savefig(CHART_PATH / "revenue_by_region.png")

        plt.close()

    def department_distribution(self):

        plt.figure(figsize=(10, 6))

        self.df["department"].value_counts().plot(kind="pie", autopct="%1.1f%%")

        plt.title("Department Distribution")

        plt.savefig(CHART_PATH / "department_distribution.png")

        plt.close()

    def sales_histogram(self):

        plt.figure(figsize=(10, 6))

        sns.histplot(self.df["sales"], kde=True)

        plt.title("Sales Distribution")

        plt.savefig(CHART_PATH / "sales_histogram.png")

        plt.close()

    def missing_value_heatmap(self):

        plt.figure(figsize=(12, 6))

        sns.heatmap(self.df.isnull(), cbar=False)

        plt.title("Missing Value Heatmap")

        plt.savefig(CHART_PATH / "missing_heatmap.png")

        plt.close()

    def revenue_boxplot(self):

        plt.figure(figsize=(10, 6))

        sns.boxplot(x=self.df["revenue"])

        plt.title("Revenue Boxplot")

        plt.savefig(CHART_PATH / "revenue_boxplot.png")

        plt.close()

    def trend_analysis(self):

        trend = self.df.groupby("date")["revenue"].sum()

        plt.figure(figsize=(14, 6))

        trend.plot()

        plt.title("Revenue Trend Analysis")

        plt.savefig(CHART_PATH / "trend_analysis.png")

        plt.close()

    def generate_all_visualizations(self):

        self.revenue_by_region()
        self.department_distribution()
        self.sales_histogram()
        self.missing_value_heatmap()
        self.revenue_boxplot()
        self.trend_analysis()
