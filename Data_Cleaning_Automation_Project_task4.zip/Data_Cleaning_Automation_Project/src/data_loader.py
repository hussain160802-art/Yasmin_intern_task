
import pandas as pd
import numpy as np
import random
from faker import Faker
from pathlib import Path

fake = Faker()

DATA_PATH = Path("data/raw_dataset.csv")

departments = [
    "Sales", "HR", "Finance", "Marketing",
    "IT", "Operations", "Support"
]

regions = [
    "North", "South", "East", "West"
]

categories = [
    "Electronics", "Furniture", "Clothing",
    "Food", "Accessories"
]

statuses = [
    "Active", "Inactive", "Pending"
]


def generate_corrupted_email(name):
    """
    Generate intentionally invalid email formats
    to simulate real-world dirty data.
    """
    email_formats = [
        f"{name}@gmail.com",
        f"{name}gmail.com",
        f"{name}@gmail",
        f"{name}#gmail.com",
        None
    ]

    return random.choice(email_formats)


def generate_dataset(records=1500):
    """
    Generate synthetic business dataset
    with intentional data quality issues.
    """

    rows = []

    for i in range(records):

        name = fake.name()

        row = {
            "Customer_ID": random.randint(1000, 9999),
            "Name": name if random.random() > 0.05 else None,
            "Email": generate_corrupted_email(name.replace(" ", "").lower()),
            "Department": random.choice(departments),
            "Sales": random.randint(-500, 5000),
            "Revenue": round(random.uniform(1000, 50000), 2),
            "Date": random.choice([
                fake.date(),
                fake.date(pattern="%d/%m/%Y"),
                fake.date(pattern="%m-%d-%Y")
            ]),
            "Region": random.choice(regions),
            "Product Category": random.choice(categories),
            "Status": random.choice(statuses)
        }

        # Add dirty formatting
        if random.random() < 0.2:
            row["Department"] = row["Department"].upper()

        if random.random() < 0.2:
            row["Region"] = "  " + row["Region"] + " "

        if random.random() < 0.1:
            row["Product Category"] = row["Product Category"].lower()

        rows.append(row)

    df = pd.DataFrame(rows)

    # Add duplicates intentionally
    duplicates = df.sample(50, random_state=42)
    df = pd.concat([df, duplicates], ignore_index=True)

    DATA_PATH.parent.mkdir(exist_ok=True)

    df.to_csv(DATA_PATH, index=False)

    print(f"Raw dataset generated at: {DATA_PATH}")


def load_dataset(path="data/raw_dataset.csv"):
    """
    Load dataset from CSV.
    """
    return pd.read_csv(path)
