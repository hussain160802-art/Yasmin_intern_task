
# Data Cleaning & Reporting Automation Project

## Project Overview
This enterprise-style automation project demonstrates a complete data engineering and data analytics workflow for handling raw business datasets with data quality issues.

The project automatically:

- Loads raw datasets
- Generates synthetic datasets
- Cleans corrupted data
- Validates schema and data quality
- Detects anomalies and outliers
- Generates reports
- Creates charts and dashboards
- Exports cleaned files
- Maintains automation logs

---

## Technologies Used

- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- OpenPyXL
- XlsxWriter

---

## Project Structure

Data_Cleaning_Automation_Project/

│── data/

│   ├── raw_dataset.csv

│   ├── cleaned_dataset.csv

│

│── reports/

│   ├── summary_report.xlsx

│   ├── automation_log.txt

│

│── visuals/

│   ├── charts/

│

│── src/

│   ├── data_loader.py

│   ├── cleaner.py

│   ├── validator.py

│   ├── report_generator.py

│   ├── visualization.py

│   ├── automation_pipeline.py

│

│── main.py

│── requirements.txt

│── README.md

---

## Features

### Dataset Generation
- Synthetic dataset generation
- 1000+ records
- Intentional corruption and inconsistencies

### Data Cleaning
- Missing value handling
- Duplicate removal
- Email validation
- Date standardization
- String cleaning
- Case normalization
- Category normalization
- Outlier detection
- Invalid record filtering

### Validation
- Schema validation
- Null checks
- Duplicate checks
- Data range validation
- Completeness checks

### Reporting
- Excel summary reports
- KPI reports
- Data quality reports
- Revenue analysis
- Department analysis
- Regional analysis

### Visualization
- Revenue charts
- Department charts
- Missing value heatmaps
- Trend analysis
- Box plots
- Histograms

---

## Installation

```bash
pip install -r requirements.txt
```

---

## Run Project

```bash
python main.py
```

---

## Outputs Generated

### Data
- cleaned_dataset.csv

### Reports
- summary_report.xlsx
- automation_log.txt

### Charts
- Revenue analysis
- Department distribution
- Region analysis
- Trend analysis
- Outlier analysis

---

## Workflow

1. Generate or load raw data
2. Clean dataset
3. Validate dataset
4. Generate visualizations
5. Generate reports
6. Export outputs

---

## Author
Professional Data Cleaning & Reporting Automation System
